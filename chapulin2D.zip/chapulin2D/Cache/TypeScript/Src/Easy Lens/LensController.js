// Main Controller
//
// Made with Easy Lens

//@input Component.ScriptComponent phrasesText
//@input Component.ScriptComponent touchEvents


try {

let phrases = ["Phrase 1", "Phrase 2", "Phrase 3", "Phrase 4"];
let currentPhraseIndex = 0;
let isAnimating = true;
const phraseDisplayTime = 3.0; // Time each phrase is displayed in seconds

function displayNextPhrase() {
    if (isAnimating) {
        currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length;
        script.phrasesText.text = phrases[currentPhraseIndex];
        phraseTimer.reset(phraseDisplayTime);
    }
}

script.phrasesText.text = phrases[currentPhraseIndex];

let phraseTimer = script.createEvent("DelayedCallbackEvent");
phraseTimer.bind(displayNextPhrase);
phraseTimer.reset(phraseDisplayTime);

script.touchEvents.onTap.add(function() {
    isAnimating = !isAnimating;
    if (isAnimating) {
        phraseTimer.reset(phraseDisplayTime);
    }
});

} catch(e) {
  print("error in controller");
  print(e);
}
