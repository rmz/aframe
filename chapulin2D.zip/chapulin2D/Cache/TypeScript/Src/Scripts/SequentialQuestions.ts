@component
export class NewScript extends BaseScriptComponent {
    onAwake() {

    }
}
