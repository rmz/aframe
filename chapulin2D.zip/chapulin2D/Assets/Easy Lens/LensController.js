
//@input Component.ScriptComponent phrasesText
//@input Component.ScriptComponent touchEvents


try {

let phrases = [
    "Haz un acto noble", 
    "Hazte miniatura", 
    "No panda el cúnico", 
    "Sea astute",
    "Calcula tus movimientos",
    "Piense en otros"];
let currentPhraseIndex = 0;
let isAnimating = true;
const phraseDisplayTime = 0.1; // Time each phrase is displayed in seconds

function displayNextPhrase() {
    if (isAnimating) {
        currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length;
        script.phrasesText.text = phrases[currentPhraseIndex];
        phraseTimer.reset(phraseDisplayTime);
    }
}

script.phrasesText.text = phrases[currentPhraseIndex];

let phraseTimer = script.createEvent("DelayedCallbackEvent");
phraseTimer.bind(displayNextPhrase);
phraseTimer.reset(phraseDisplayTime);

script.touchEvents.onTap.add(function() {
    isAnimating = !isAnimating;
    if (isAnimating) {
        phraseTimer.reset(phraseDisplayTime);
    }
});

} catch(e) {
  print("error in controller");
  print(e);
}